package com.example.invoiceplusfullflutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
